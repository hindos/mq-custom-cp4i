#!/bin/bash
#Copyright IBM - 2011
#Author: Marc Verhiel
#add /usr/bin to path for sed
export PATH=/usr/bin:$PATH

#dump what gets passed to us
echo inputParm1="$1"
echo inputParm2="$2"

#parse the TMC (parm1) 
#tmc=${1:0:4}
#version=${1:4:4}
#qName=${1:8:48}
#processName=${1:56:48}
#triggerData=${1:104:64}
#applType=${1:168:4}
#applId=${1:172:256}
#envrData=${1:428:128}
#userData=${1:556:128}
#qMgr=${1:684:48}

tmc=$(echo "$1"|awk '{print substr($0,0,4)}')
version=$(echo "$1"|awk '{print substr($0,5,4)}')
qName=$(echo "$1"|awk '{print substr($0,9,48)}')
processName=$(echo "$1"|awk '{print substr($0,57,48)}')
triggerData=$(echo "$1"|awk '{print substr($0,105,64)}')
applType=$(echo "$1"|awk '{print substr($0,169,4)}')
applId=$(echo "$1"|awk '{print substr($0,173,256)}')
envrData=$(echo "$1"|awk '{print substr($0,429,128)}')
userData=$(echo "$1"|awk '{print substr($0,557,128)}')
qMgr=$(echo "$1"|awk '{print substr($0,685,48)}')

echo tmc="'"$tmc"'"
echo version="'"$version"'"
echo qName="'"$qName"'"
echo processName="'"$processName"'"
echo triggerData="'"$triggerData"'"
echo applType="'"$applType"'"
echo applId="'"$applId"'"
echo envrData="'"$envrData"'"
echo userData="'"$userData"'"
echo qMgr="'"$qMgr"'"

#strip trailing blanks - uses sed 
qMgr=$(echo ${qMgr} | sed -e 's/^ *//g;s/ *$//g')
qName=$(echo ${qName} | sed -e 's/^ *//g;s/ *$//g')
triggerData=$(echo ${triggerData} | sed -e 's/^ *//g;s/ *$//g')
userData=$(echo ${userData} | sed -e 's/^ *//g;s/ *$//g')

echo qMgr="$qMgr"
expr length "$qMgr"
echo qName="$qName"
expr length "$qName"
echo triggerData="$triggerData"
expr length "$triggerData"
echo userData="$userData"
expr length "$userData"

#set tstamp value to append to file name to ensure it is unique
tstamp=`date +%Y%m%d_%H%M%S_%N`

#copy Parm2 to meaningful name
#connectionName=$2

#echo what we will execute
echo executing "/opt/mqm/bin/runmqdlq $qName $qMgr <$userData"

#execute dead letter handler
/opt/mqm/bin/runmqdlq $qName $qMgr <$userData

exit
