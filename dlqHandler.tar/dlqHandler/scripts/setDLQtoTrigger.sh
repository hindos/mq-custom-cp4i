#!/bin/bash
#Copyright IBM - 2018
#Author: Marc Verhiel
#add /usr/bin to path for sed
export PATH=/usr/bin:$PATH

#dump what gets passed to us
echo inputParm1=$1
echo inputParm2=$2

sleep $2
echo 'ALTER QL(RBL.DLQ.IIB_EXCEPTION) TRIGGER' | /opt/mqm/bin/runmqsc $1

exit
